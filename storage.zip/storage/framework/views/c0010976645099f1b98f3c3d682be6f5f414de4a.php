<!DOCTYPE html>
<html>

<?php echo $__env->make("dashboard.global.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <?php echo $__env->make("dashboard.global.top", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make("dashboard.global.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="mobile-menu-overlay"></div>

    <?php echo $__env->yieldContent("content"); ?>
    <!-- welcome modal start -->
    <?php echo $__env->make("dashboard.global.welcomeModal", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("dashboard.global.footerScript", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- welcome modal end -->
    <?php echo $__env->yieldContent("footer_scripts"); ?>
    <?php echo $__env->yieldContent("footer_modals"); ?>
    <?php echo $__env->yieldContent("footer_modals_rs_password_ptc"); ?>
    <?php echo $__env->yieldContent("footer_modals_pengguna"); ?>
    <?php echo $__env->yieldContent("footer_modals_pembayaran"); ?>
    <?php echo $__env->yieldContent("footer_modals_pettyCash"); ?>
    <?php echo $__env->yieldContent('footer_modals_pettyCashEdit'); ?>
    <?php echo $__env->yieldContent("footer_endMenu_section"); ?>
    <?php echo $__env->yieldContent("footer_modals_holding"); ?>
    <?php echo $__env->yieldContent("footer_modals_unit"); ?>

    <!-- Pengadaan -->
    <?php echo $__env->yieldContent("footer_add_pengadaan"); ?>
    <?php echo $__env->yieldContent("footer_add_pengaturan"); ?>
    <?php echo $__env->yieldContent("footer_add_profiles"); ?>
</body>

</html><?php /**PATH C:\Users\goesmang\Documents\project\radityaholding\resources\views/dashboard/index.blade.php ENDPATH**/ ?>