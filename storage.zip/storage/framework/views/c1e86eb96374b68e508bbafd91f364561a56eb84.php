<div class="div_display_unit_sub" id="table_surat_lainnya" style="display: none;">
    <table class="table stripe hover nowrap">
        <thead style="background: #F5F5F5; height: 60px;">
            <tr>
                <th>Prioritas</th>
                <th class="table-plus datatable-nosort">Role</th>
                <th>Unit Bisnis</th>
                <th>Nama Unit Bisnis</th>
                <th>Tugas</th>
                <th class="datatable-nosort"></th>
            </tr>
        </thead>
        <tbody>
            <?php
            $an = 0;
            ?>
            <?php $__currentLoopData = $users_pengadaan_lainnya; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $an++;
            ?>
            <tr>
                <td>
                    <input type="hidden" id=<?php echo e("id_role_pengadaan_lainnya_".$an); ?> name=<?php echo e("id_role_lainnya__".$an); ?>

                        class="form-control" value="<?php echo e($row->id); ?>" style="width: 70px!important;" />
                    <input type="number" id=<?php echo e("role_pengadaan_lainnya_".$an); ?> name=<?php echo e("role_lainnya__".$an); ?>

                        class="form-control" value="<?php echo e($row->urutan); ?>" style="width: 70px!important;" />
                </td>
                <td class="table-plus">
                    <?php
                    echo $row->name
                    ?>
                </td>
                <td>
                    <?php echo $unitUsaha->name; ?>
                </td>
                <td>
                    <label class="switch">
                        <?php
                        if ($row->aktif == "1") {
                        ?>
                            <input type="checkbox" class="switch-input" value="1" checked
                                id=<?php echo e("checked_role_lainnya_".$an); ?> name=<?php echo e("checked_role_lainnya_".$an); ?>>
                        <?php
                        } else {
                        ?>
                            <input type="checkbox" class="switch-input" value="1" id=<?php echo e("checked_role_lainnya_".$an); ?>

                                name=<?php echo e("checked_role_lainnya_".$an); ?>>
                        <?php
                        }
                        ?>

                        <span class="switch-slider"></span>
                    </label>
                </td>
                <td>
                    <select class="form-control" id=<?php echo e("scLainnya_role_pengadaan_lainnya_".$an); ?>

                        name=<?php echo e("scLainnya_role_pengadaan_lainnya_".$an); ?>>
                        <option value="0"> Mengajukan </option>
                        <option value="1" <?php echo e($row->menyetujui === 1 ? "selected" : ""); ?>> Menyetujui </option>
                    </select>
                </td>
                <!-- <td>
                <div class="dropdown">
                    <a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle" href="#" role="button"
                        data-toggle="dropdown">
                        <i class="dw dw-more"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">
                        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#bd-password-modal-lg">
                            <i class="dw dw-lock"></i> Ganti Password
                        </a>
                        <a class="dropdown-item" href="#"><i class="dw dw-eye"></i> View</a>
                        <a class="dropdown-item" href="#"><i class="dw dw-edit2"></i> Edit</a>
                        <a class="dropdown-item" href="#"><i class="dw dw-delete-3"></i> Delete</a>
                    </div>
                </div>
            </td> -->
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <button class="btn btn-primary" type="submit" style="margin-left: 20px; margin-top: 20px;">
        <i class="fa fa-refresh"></i>&nbsp; Update Role
    </button>
</div><?php /**PATH C:\Users\goesmang\Documents\project\radityaholding\resources\views/dashboard/pages/unitUsaha/component/sub/surat/lainnnya.blade.php ENDPATH**/ ?>