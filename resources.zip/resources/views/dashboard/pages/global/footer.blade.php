<!-- welcome modal end -->
<!-- js -->
<script src={{ asset("src/scripts/swal2.js") }}></script>
<script src={{ asset("vendors/scripts/core.js") }}></script>
<script src={{ asset("vendors/scripts/script.min.js") }}></script>
<script src={{ asset("vendors/scripts/process.js") }}></script>
<script src={{ asset("vendors/scripts/layout-settings.js") }}></script>
<script src="https://cdn.ckeditor.com/4.22.1/standard/ckeditor.js"></script>

<script src="https://cdn.jsdelivr.net/npm/quill-better-table@1.2.8/dist/quill-better-table.min.js"></script>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NXZMQSS" height="0" width="0" style="display: none; visibility: hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
