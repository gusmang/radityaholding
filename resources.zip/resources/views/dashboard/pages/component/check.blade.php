<div style="width: 100%; z-index: 20px; top: 20px; background: #416351; height: 4px;"></div>
<div style="width: 40px; height: 40px; padding: 7px; border-radius: 50%; background: #416351; position: absolute; z-index: 50; top: -20px;">
    <div style="width: 26px; height: 26px; border-radius: 50%; background: #FFFFFF; display: flex; align-items: center; justify-content: center;">
        <i class="fa fa-check" style="font-size: 16px; color: #416351;"></i>
    </div>
</div>
