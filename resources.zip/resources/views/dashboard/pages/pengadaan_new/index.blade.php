@extends('dashboard.index')

@section("content")
<div class="main-container">
    <div class="pd-ltr-20 xs-pd-20-10">
        <div class="min-height-200px">
            <div class="page-header mb-30">
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <div class="title">
                            <h4>Permohonan Petty Cash</h4>
                            <small>Atur dan lihat daftar petty cash pada tabel di bawah</small>
                        </div>
                        {{-- <nav aria-label="breadcrumb" role="navigation">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="index.html">Home</a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">
                                    List
                                </li>
                            </ol>
                        </nav> --}}
                    </div>
                    <div class="col-md-6 col-sm-12 text-right">
                        <div style="padding:0; width: 100%; clear: both;">
                            <a href="{{ route('addPettyCash') }}" class="btn-block" type="button">
                                <button class="btn btn-primary" style="float: right;">
                                    <i class="fa fa-plus"></i>&nbsp; Tambah Permohonan Baru
                                </button>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card-box mb-10">
                <div class="pd-20">
                    <div class="row">
                        <div class="col-12">
                            <div>
                                <div class="row">
                                    <div class="col-3">
                                        <div><label> Cari Surat : </label></div>
                                        <input type="text" name="search_surat" placeholder="Cari Surat ..."
                                            class="form-control" />
                                    </div>
                                    <div class="col-3">
                                        <div><label> Status : </label></div>
                                        <select name="status_surat" placeholder="Status Surat ..."
                                                class="form-control">
                                                <option value="">- Pilih Status Surat -</option>
                                                <?php
                                                    $urgent_sts = "";
                                                    $onAppr_sts = "";
                                                    $pending_sts = "";
                                                    $finished_sts = "";
                                                    $rejected_sts = "";

                                                    if(isset($_GET['status_surat'])){
                                                        if($_GET['status_surat'] == "1"){
                                                            $urgent_sts = "selected";
                                                        }
                                                        else if($_GET['status_surat'] == "2"){
                                                            $onAppr_sts = "selected";
                                                        }
                                                        else if($_GET['status_surat'] == "3"){
                                                            $pending_sts = "selected";
                                                        }
                                                        else if($_GET['status_surat'] == "4"){
                                                            $finished_sts = "selected";
                                                        }
                                                        else if($_GET['status_surat'] == "5"){
                                                            $rejected_sts = "selected";
                                                        }
                                                    }
                                                ?>
                                                <option value="1" <?php echo $urgent_sts; ?>>Urgent</option>
                                                <option value="2" <?php echo $onAppr_sts; ?>>On Approve</option>
                                                <option value="3" <?php echo $pending_sts; ?>>Pending</option>
                                                <option value="4" <?php echo $finished_sts; ?>>Finished</option>
                                                <option value="5" <?php echo $rejected_sts; ?>>Rejected</option>
                                        </select>
                                    </div>
                                    <div class="col-3">
                                        <div><label> Tanggal Pengajuan : </label></div>
                                        <input type="text" class="dateRange" id="dateRange" name="tanggal_surat" placeholder="Tanggal Pengajuan ..."
                                            class="form-control" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="pb-20" style="overflow: auto; margin-top: 30px;">
                <div class="mt-40">
                    <div style="display: flex; flex-direction: row; margin-top: 10px; padding:0 10px;">
                        <div style="padding:0 20px 20px 20px; color: #666666; cursor: pointer;"
                            class="tab-list {{ $active_detail }} " id="tab-one-detail"
                            onclick="active_tab(this.id , 1)">
                            On Progress
                        </div>
                        <div style="padding:0 20px; color: #666666; cursor: pointer;"
                            class="tab-list {{ $active_pengadaan }} " id="tab-two-detail"
                            onclick="active_tab(this.id , 3);">
                            Approved
                        </div>
                        <div style="padding:0 20px; color: #666666; cursor: pointer;"
                            class="tab-list {{ $active_pembayaran }} " id="tab-three-detail"
                            onclick="active_tab(this.id , 2)">
                            Rejected
                        </div>
                    </div>
                    <div
                        style="border-bottom: 1px solid #DDDDDD; margin-top: 0;  padding:0 10px; margin-left: 10px; margin-right: 10px;">
                        <div style="display: flex; flex-direction: row;">
                            <div style="padding:0 10px; width: 170px;"></div>
                            <div style="padding:0 10px; width: 170px;"></div>
                            <div style="padding:0 10px; width: 152px;"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-12 col-12" style="padding:0 0 30px 0; margin: 0; overflow: hidden;">
                <div class="row">
                    @php
                    $an = 0;
                    @endphp
                    @foreach($pengadaan as $row)
                    @php
                    $an++;
                    @endphp
                    <div class="col-md-4 col-6 mt-4">
                        <div class="col-md-12 col-12 card" style="min-height: 200px; border-radius: 15px; overflow: hidden; margin: 0; padding:0;">
                            <table style="height: 80px; border-bottom: 1px solid #DDDDDD;">
                                <tbody>
                                    <td style="padding: 20px 10px 20px 30px;">
                                        <i class="fa fa-users"></i>
                                    </td>
                                    <td style="padding: 20px 20px 20px 0;">
                                        <div>
                                            <h5 style="font-size: 18px; font-weight: 400;"> Pengajuan
                                                {{ $row->no_surat }}
                                            </h5>
                                        </div>

                                        <div class="mt-2">
                                            <h5 style="font-size: 14px; font-weight: normal; letter-spacing: 2px">
                                                {{ $row->created_at }}
                                            </h5>
                                        </div>
                                    </td>
                                </tbody>
                            </table>

                            <div style="padding: 10px 20px 20px 20px;">
                                <div class="mt-2">
                                    <h5 style="font-size: 12px; font-weight: normal; letter-spacing: 2px">
                                        {{ $row->no_surat }}
                                    </h5>
                                </div>

                                <div class="mt-4">
                                    <h5 style="font-size: 16px; font-weight: 500;"> {{ $row->title }} </h5>
                                </div>

                                <div class="mt-2" style="height: 100px;">
                                    <h5
                                        style="font-size: 12px; font-weight: normal; line-height: 21px; letter-spacing: 2px">
                                        {{ substr(strip_tags($row->detail),0,200)." ..." }}
                                    </h5>
                                </div>
                            </div>

                            <div style="border-top: 1px solid #DDDDDD; padding: 20px;">
                                <div class="col-md-12" style="margin:0; padding: 0 10px;">
                                    <div class="row">
                                        <div class="col-md-7" style="margin:0; padding: 0;">
                                            <div> Nominal Pengajuan </div>
                                            <div> Rp {{ app('App\Helpers\Str')->rupiah($row->nominal_pengajuan) }}
                                            </div>
                                        </div>
                                        <div class="col-md-5 d-flex justify-content-end" style="margin:0; padding: 0;">
                                            <a href="{{route('detailPettyCash',['index'=> $row->id])}}">
                                                <button class="btn btn-primary-outlined">
                                                    Lihat Detail
                                                </button>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <?php
                            if ($row->position === "0") {
                            ?>
                                <div
                                    style="height: 50px; display: flex; border-radius: 0 0 15px 15px; font-size: 14px; justify-content: center; align-items: center; color: #ffffff; width: 100%; border-top: 1px solid #DDDDDD; background: brown;">
                                    <div style="margin-right: 10px;"> <i class="fa fa-clock-o" style="font-size: 18px;"></i>
                                    </div>
                                    <div>
                                        Menunggu persetujuan {{ $row->position }}
                                    </div>
                                </div>
                            <?php
                            } else {
                            ?>
                                <div
                                    style="height: 50px; display: flex; border-radius: 0 0 15px 15px; font-size: 14px; justify-content: center; align-items: center; color: #ffffff; width: 100%; border-top: 1px solid #DDDDDD; background: green;">
                                    <div style="margin-right: 10px;"> <i class="fa fa-check-circle"
                                            style="font-size: 18px;"></i> </div>
                                    <div>
                                        Dokumen berhasil terverifikasi
                                    </div>
                                </div>
                            <?php
                            }
                            ?>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>

            <!-- Simple Datatable start -->
            @include("dashboard.pages.users.components.modalUser")


        </div>
    </div>
</div>

<script type="text/javascript">
    function active_tab(id, page) {
        $(".tab-list").removeClass("active-tab");
        $("#" + id).addClass("active-tab");

        if (page === 1) {
            $(".div_display_unit").hide();
            $("#div_tab_detail").fadeIn("slow");
        } else if (page === 2) {
            $(".div_display_unit").hide();
            $("#div_tab_pengadaan").fadeIn("slow");
        } else if (page === 3) {
            $(".div_display_unit").hide();
            $("#div_tab_pembayaran").fadeIn("slow");
        } else if (page === 4) {
            $(".div_display_unit").hide();
            $("#div_tab_user").fadeIn("slow");
        }
    }
</script>
@endsection