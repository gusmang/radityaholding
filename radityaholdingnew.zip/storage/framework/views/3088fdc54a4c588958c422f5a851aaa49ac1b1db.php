<div class="modal fade bs-persetujuan-modal" id="bs-persetujuan-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    
    <input type="hidden" id="teks_dokumen_persetujuan" name="teks_dokumen_persetujuan" />
    <?php echo csrf_field(); ?>
    <div class="modal-dialog modal modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myLargeModalLabel">
                    Verifikasi Berkas ?
                </h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                    ×
                </button>
            </div>
            <div class="modal-body">
                <div class="col-md-12">
                    <div>
                        <input type="hidden" id="teks_branch_approval" name="teks_branch_approval" />
                        <input type="hidden" id="teks_person_approval" name="teks_person_approval" />
                        <input type="hidden" name="t_login" id="t_login" value="<?php echo e(Auth::user()->id); ?>" />

                        Apakah anda yakin ingin melakukan verifikasi berkas ini ? Verifikasi akan dilanjutkan ke tahap pembuatan surat persetujuan ?
                        <b>
                            <span id="span_pengadaan_diteruskan"></span>
                        </b>
                    </div>
                    
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary-outlined" data-dismiss="modal">
                    Batal
                </button>
                <button type="submit" class="btn btn-primary">
                    Verifikasi
                </button>
            </div>
        </div>
    </div>
    
</div>
<?php /**PATH C:\Users\goesmang\Documents\project\radityaholding\resources\views/dashboard/pages/pengadaan_new/detail/sub/component/modals/modalPersetujuan.blade.php ENDPATH**/ ?>