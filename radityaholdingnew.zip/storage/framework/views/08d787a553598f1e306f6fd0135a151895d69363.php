 
 
<?php /**PATH C:\Users\goesmang\Documents\project\radityaholding\resources\views/dashboard/global/welcomeModal.blade.php ENDPATH**/ ?>