<div class="modal fade bs-verifikasi-modal-pettyCash" id="bs-verifikasi-modal-pettyCash" tabindex="-1" role="dialog"
    aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <form method="post" id="form-verifikasi-pettycash-add" name="form-verifikasi-pettycash-add">
        <input type="hidden" id="teks_dokumen_pengadaan" name="teks_dokumen_pengadaan" />
        <?php echo csrf_field(); ?>
        <div class="modal-dialog modal modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myLargeModalLabel">
                        Verifikasi Berkas ?
                    </h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                        ×
                    </button>
                </div>
                <div class="modal-body">
                    <div class="col-md-12">
                        <div>
                            <input type="hidden" id="teks_branch_approval" name="teks_branch_approval" />
                            <input type="hidden" id="teks_person_approval_new" name="teks_person_approval_new"
                                value="<?php echo e(Auth::user()->role_id); ?>" />
                            <input type="hidden" name="t_index" id="t_index" value="<?php echo e($pengadaan->id); ?>" />

                            Apakah anda yakin ingin melakukan verifikasi berkas ini ? Verifikasi akan diteruskan ke
                            <b><span id="teruskan_person"></span></b>
                            <b>
                                <span id="span_pengadaan_diteruskan"></span>
                            </b>
                        </div>
                        <div>
                            <label class="mt-4" style="font-size: 14px;"> Catatan : </label>
                            <textarea rows="4" class="form-control" name="verifikasi_berkas"
                                id="verifikasi_berkas"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary-outlined" data-dismiss="modal">
                        Batal
                    </button>
                    <button type="submit" class="btn btn-primary">
                        Verifikasi
                    </button>
                </div>
            </div>
        </div>
    </form>
</div><?php /**PATH C:\Users\goesmang\Documents\project\radityaholding\resources\views/dashboard/pages/pettyCash/detail/sub/component/modals/modalVerifikasi.blade.php ENDPATH**/ ?>